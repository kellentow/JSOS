"use strict";
(() => {
  // ../../../../src/helpers.ts
  function waitForDefined(getValue, interval = 50, timeout) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      let id;
      const check = () => {
        try {
          const value = getValue();
          if (value !== void 0) {
            if (id !== void 0)
              clearInterval(id);
            resolve(value);
            return true;
          }
          if (timeout != null && Date.now() - start > timeout) {
            if (id !== void 0)
              clearInterval(id);
            reject(new Error("waitForDefined: timeout"));
            return true;
          }
        } catch (err) {
          if (id !== void 0)
            clearInterval(id);
          reject(err);
          return true;
        }
        return false;
      };
      if (check())
        return;
      id = setInterval(() => {
        check();
      }, interval);
    });
  }
  var GWindow = class {
    #id;
    #ipc;
    constructor(glass_ipc, on_load) {
      if (glass_ipc === void 0)
        throw Error("tried to summon a window before could communicate with glass");
      this.#ipc = glass_ipc;
      this.#id = "";
      this.document = document;
      this.#ipc.send({ type: "new" });
      waitForDefined(() => {
        return this.#ipc.recv();
      }).then((msg) => {
        if (!msg || msg.type != "new") {
          throw Error("Glass sent unexpected message");
        }
        this.document = msg.document;
        this.#id = msg.id;
        if (on_load)
          on_load();
      });
    }
    move(x, y, z) {
      this.#ipc.send({ type: "pos", target: this.#id, x, y, z });
    }
    scale(width, height) {
      this.#ipc.send({ type: "size", target: this.#id, width, height });
    }
    track() {
      this.#ipc.send({ type: "track", target: this.#id, pid: window.proc.getPID() });
    }
    destroy() {
      this.#ipc.send({ type: "destroy", target: this.#id });
    }
  };

  // src/index.ts
  document.addEventListener("os-load", async () => {
    let process = window.proc;
    let os = window.os;
    let fs = window.fs();
    let root = os.getRootProc();
    let glass = void 0;
    for (var i = 0; i < root.children.length; i++) {
      if (root.children[i].getName() == "Glass") {
        glass = root.children[i];
      }
    }
    if (glass === void 0)
      throw Error("Could not find Glass");
    os.createIPC(process, glass);
    let Gwindow = new GWindow(window.IPCs[0], () => {
      let fd = fs.open("/apps/fileexplorer/index.html");
      let bytes = [];
      if (fd) {
        let out = fd.read();
        while (out !== null) {
          bytes.push(out);
          out = fd.read();
        }
      }
      Gwindow.document.documentElement.innerHTML = new TextDecoder().decode(new Uint8Array(bytes));
      let stale = true;
      let cwd = "/";
      function refreshFolder(path, element, level = 0) {
        let contents = fs.lsdir(path);
        let can_rm = fs.getPerms(path) & 2;
        if (contents) {
          contents.forEach((item) => {
            let item_element = document.createElement("div");
            item_element.classList.add("node");
            item_element.textContent = "|   ".repeat(level + 1) + item;
            let delete_button = document.createElement("button");
            delete_button.innerText = "Trash";
            delete_button.style.right = "2em";
            delete_button.addEventListener("click", () => {
              fs.rm(path + "/" + item);
              stale = true;
            });
            let is_dir = !!fs.isdir(path + "/" + item);
            if (is_dir) {
              item_element.innerText += "/";
            }
            if (can_rm) {
              item_element.appendChild(delete_button);
            }
            if (is_dir) {
              let cd_button = document.createElement("button");
              cd_button.innerText = ">";
              cd_button.addEventListener("click", () => {
                cwd = fs.normalize(path + "/" + item);
                stale = true;
              });
              item_element.appendChild(cd_button);
              if (level < 1) {
                refreshFolder(path + "/" + item, item_element, level + 1);
              }
            }
            element.appendChild(item_element);
          });
        }
      }
      let reload_button = Gwindow.document.getElementById("reload");
      let pid_shower = Gwindow.document.getElementById("pid");
      let main = Gwindow.document.getElementById("main");
      reload_button.onclick = () => {
        stale = true;
      };
      Gwindow.move(100, 100, 3);
      Gwindow.scale(300, 400);
      setTimeout(() => {
        window.requestSudo("dev purposes only");
        stale = true;
      }, 100);
      function staleHandler() {
        if (stale) {
          stale = false;
          pid_shower.innerText = "User: " + String(os.getProcUser(window.prockey, process));
          main.innerHTML = "";
          main.innerText = cwd;
          if (cwd != "/") {
            let back_button = document.createElement("button");
            back_button.innerText = "../";
            back_button.addEventListener("click", () => {
              cwd = fs.dirname(cwd);
              stale = true;
            });
            main.appendChild(back_button);
          }
          refreshFolder(cwd, main);
        }
        requestAnimationFrame(staleHandler);
      }
      staleHandler();
    });
  });
})();
