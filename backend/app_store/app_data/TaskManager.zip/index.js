"use strict";
(() => {
  // ../../../../src/helpers.ts
  function waitForDefined(getValue, interval = 50, timeout) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      let id;
      const check = () => {
        try {
          const value = getValue();
          if (value !== void 0) {
            if (id !== void 0)
              clearInterval(id);
            resolve(value);
            return true;
          }
          if (timeout != null && Date.now() - start > timeout) {
            if (id !== void 0)
              clearInterval(id);
            reject(new Error("waitForDefined: timeout"));
            return true;
          }
        } catch (err) {
          if (id !== void 0)
            clearInterval(id);
          reject(err);
          return true;
        }
        return false;
      };
      if (check())
        return;
      id = setInterval(() => {
        check();
      }, interval);
    });
  }
  var GWindow = class {
    #id;
    #ipc;
    constructor(glass_ipc, on_load) {
      if (glass_ipc === void 0)
        throw Error("tried to summon a window before could communicate with glass");
      this.#ipc = glass_ipc;
      this.#id = "";
      this.document = document;
      this.#ipc.send({ type: "new" });
      waitForDefined(() => {
        return this.#ipc.recv();
      }).then((msg) => {
        if (!msg || msg.type != "new") {
          throw Error("Glass sent unexpected message");
        }
        this.document = msg.document;
        this.#id = msg.id;
        if (on_load)
          on_load();
      });
    }
    move(x, y, z) {
      this.#ipc.send({ type: "pos", target: this.#id, x, y, z });
    }
    scale(width, height) {
      this.#ipc.send({ type: "size", target: this.#id, width, height });
    }
    track() {
      this.#ipc.send({ type: "track", target: this.#id, pid: window.proc.getPID() });
    }
    destroy() {
      this.#ipc.send({ type: "destroy", target: this.#id });
    }
  };

  // src/index.ts
  document.addEventListener("os-load", async () => {
    let process = window.proc;
    let os = window.os;
    let fs = window.fs();
    let root = os.getRootProc();
    let glass = void 0;
    for (var i = 0; i < root.children.length; i++) {
      if (root.children[i].getName() == "Glass") {
        glass = root.children[i];
      }
    }
    if (glass === void 0)
      throw Error("Could not find Glass");
    os.createIPC(process, glass);
    let Gwindow = new GWindow(window.IPCs[0], () => {
      let fd = fs.open("/apps/taskmanager/index.html");
      let bytes = [];
      if (fd) {
        let out = fd.read();
        while (out !== null) {
          bytes.push(out);
          out = fd.read();
        }
      }
      Gwindow.document.documentElement.innerHTML = new TextDecoder().decode(new Uint8Array(bytes));
      function refresh(proc, element, level = 0) {
        element.style.whiteSpace = "pre";
        element.textContent = "|   ".repeat(level) + `${proc.getName()}    pid: ${proc.getPID()}    uid: ${os.getProcUser(window.prockey, proc)}`;
        let kill_button = document.createElement("button");
        kill_button.textContent = "Kill";
        kill_button.onclick = () => {
          os.killProcess(window.prockey, proc);
        };
        kill_button.style.right = "10px";
        element.appendChild(kill_button);
        element.style.marginLeft = "0px";
        if (proc) {
          proc.children.forEach((item) => {
            let item_element = document.createElement("div");
            refresh(item, item_element, level + 1);
            element.appendChild(item_element);
          });
        }
      }
      setInterval(() => {
        Gwindow.document.getElementById("main").innerHTML = "";
        refresh(os.getRootProc(), Gwindow.document.getElementById("main"));
      }, 500);
      Gwindow.move(500, 100, 3);
      Gwindow.scale(300, 400);
    });
  });
})();
