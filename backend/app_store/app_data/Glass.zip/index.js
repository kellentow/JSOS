"use strict";
(() => {
  // ../../../../src/helpers.ts
  function waitForDefined(getValue, interval = 50, timeout) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      let id;
      const check = () => {
        try {
          const value = getValue();
          if (value !== void 0) {
            if (id !== void 0)
              clearInterval(id);
            resolve(value);
            return true;
          }
          if (timeout != null && Date.now() - start > timeout) {
            if (id !== void 0)
              clearInterval(id);
            reject(new Error("waitForDefined: timeout"));
            return true;
          }
        } catch (err) {
          if (id !== void 0)
            clearInterval(id);
          reject(err);
          return true;
        }
        return false;
      };
      if (check())
        return;
      id = setInterval(() => {
        check();
      }, interval);
    });
  }

  // src/index.ts
  var windows = {};
  var pdoc = void 0;
  var MAX_MSGS_PER_IPC = 100;
  function IPCHandler(ipc) {
    if (!pdoc)
      throw new Error("User refused DOM access");
    pdoc = pdoc;
    let processed = 0;
    while (processed < MAX_MSGS_PER_IPC) {
      let msg;
      try {
        msg = ipc.recv();
      } catch (err) {
        console.error("IPC.recv threw:", err);
        break;
      }
      if (msg === void 0)
        break;
      processed++;
      try {
        if (msg.type === "pos") {
          let win = windows[msg.target];
          if (!win)
            continue;
          if (typeof msg.x === "number")
            win.x = msg.x;
          if (typeof msg.y === "number")
            win.y = msg.y;
          if (msg.z && typeof msg.z === "number")
            win.z = msg.z;
        } else if (msg.type === "size") {
          let win = windows[msg.target];
          if (!win)
            continue;
          if (typeof msg.width === "number")
            win.width = msg.width;
          if (typeof msg.height === "number")
            win.height = msg.height;
        } else if (msg.type === "new") {
          let win = pdoc.createElement("iframe");
          let id = crypto.randomUUID();
          win.style.borderWidth = "0px";
          win.setAttribute("Glass-id", id);
          win.srcdoc = "";
          win.sandbox = "allow-same-origin";
          windows[id] = {
            x: 0,
            y: 0,
            z: 0,
            width: 0,
            height: 0,
            element: win,
            id,
            tracking: void 0
          };
          pdoc.body.appendChild(win);
          win.addEventListener("load", () => {
            console.log("New window made", win);
            ipc.send({ type: "new", document: win.contentDocument, id });
          });
        } else if (msg.type == "info") {
          let windows_safe = [];
          Object.values(windows).forEach((window2) => {
            windows_safe.push({
              x: window2.x,
              y: window2.y,
              z: window2.z,
              width: window2.width,
              height: window2.height,
              id: window2.id
            });
          });
          ipc.send({
            type: "info",
            sc: {
              x: 0,
              y: 0,
              width: pdoc.documentElement.clientWidth,
              height: pdoc.documentElement.clientHeight
            },
            windows: windows_safe
          });
        } else if (msg.type == "track") {
          let win = windows[msg.target];
          if (!win)
            continue;
          if (typeof msg.pid === "number")
            win.tracking = msg.pid;
        } else if (msg.type == "destroy") {
          let win = windows[msg.target];
          if (!win)
            continue;
          win.element.remove();
          delete windows[win.id];
        } else {
          console.warn("Unknown IPC message type:", msg.type);
        }
      } catch (err) {
        console.error("Error handling IPC message:", err);
      }
    }
    if (processed >= MAX_MSGS_PER_IPC) {
      console.warn("Reached message cap for one IPC this frame; remaining messages will be processed next frame");
    }
  }
  document.addEventListener("os-load", async () => {
    try {
      await waitForDefined(() => window.proc, 50, 1e3);
      pdoc = window.parent_doc();
      if (!pdoc) {
        await window.proc.askPermissions(16, "Permission to edit the DOM is required to show windows");
        pdoc = window.parent_doc();
      }
      if (!pdoc)
        throw new Error("User refused DOM access");
      pdoc = pdoc;
      pdoc.body.style.overflow = "clip";
      pdoc.body.style.margin = "0px";
      pdoc.documentElement.style.overflow = "clip";
      requestAnimationFrame(updateLoop);
      console.log("Glass is (probably) up!");
    } catch (err) {
      console.error("Failed to initialize Glass:", err);
    }
  });
  function updateLoop() {
    const IPCs = window.IPCs ?? [];
    IPCs.forEach((ipc) => {
      IPCHandler(ipc);
    });
    Object.values(windows).forEach((win, i) => {
      if (win.tracking !== void 0 && window.os.getProcess(win.tracking) === void 0) {
        win.element.remove();
        delete windows[win.id];
      }
      const el = win.element;
      el.style.position = "absolute";
      el.style.left = `${win.x}px`;
      el.style.top = `${win.y}px`;
      el.style.width = `${win.width}px`;
      el.style.height = `${win.height}px`;
      el.style.overflow = "clip";
      el.style.zIndex = String(win.z);
    });
    requestAnimationFrame(updateLoop);
  }
})();
